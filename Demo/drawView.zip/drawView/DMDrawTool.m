//
//  DMDrawTool.m
//  HelloWorld
//
//  Created by roki on 2018/10/8.
//  Copyright © 2018年 rokihann.ideahatcher. All rights reserved.
//

#import "DMDrawTool.h"

typedef NS_ENUM(NSUInteger, DrawToolType) {
    DrawToolTypeBrush,
    DrawToolTypeRubber
};

@implementation DMDrawTool



@end
